<?php
require_once __DIR__ . '/../config/db.php';

class Cliente {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function listar() {
        $stmt = $this->pdo->query("SELECT * FROM clientes");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function agregar($nombre, $email) {
        $stmt = $this->pdo->prepare("INSERT INTO clientes (nombre, email) VALUES (?, ?)");
        return $stmt->execute([$nombre, $email]);
    }
}
?>

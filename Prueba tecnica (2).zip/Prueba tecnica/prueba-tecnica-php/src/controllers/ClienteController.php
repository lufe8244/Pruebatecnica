<?php
require_once __DIR__ . '/../models/Cliente.php';

class ClienteController {
    private $cliente;

    public function __construct($pdo) {
        $this->cliente = new Cliente($pdo);
    }

    public function index() {
        return $this->cliente->listar();
    }

    public function store($nombre, $email) {
        return $this->cliente->agregar($nombre, $email);
    }
}
?>

<?php

class OrderController {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    private function validarProductoParaCliente($client_id, $product_id) {
        $sql = "SELECT COUNT(*) FROM client_product WHERE client_id = :client_id AND product_id = :product_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'client_id' => $client_id,
            'product_id' => $product_id
        ]);
        return $stmt->fetchColumn() > 0;
    }

    private function validarStockDisponible($product_id, $cantidad) {
        $sql = "SELECT stock FROM products WHERE id = :product_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['product_id' => $product_id]);
        $stock_disponible = $stmt->fetchColumn();
        
        return $stock_disponible >= $cantidad;
    }

    private function descontarStock($product_id, $cantidad) {
        $sql = "UPDATE products SET stock = stock - :cantidad WHERE id = :product_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'cantidad' => $cantidad,
            'product_id' => $product_id
        ]);
    }

    public function procesarOrden($client_id, $productos) {
        try {
            $this->pdo->beginTransaction();
            
            foreach ($productos as $producto) {
                if (!$this->validarProductoParaCliente($client_id, $producto['id'])) {
                    throw new Exception("El producto {$producto['id']} no está disponible para el cliente.");
                }

                if (!$this->validarStockDisponible($producto['id'], $producto['cantidad'])) {
                    throw new Exception("Stock insuficiente para el producto {$producto['id']}.");
                }

                $this->descontarStock($producto['id'], $producto['cantidad']);
            }

            $sql = "INSERT INTO orders (client_id, created_at) VALUES (:client_id, NOW())";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(['client_id' => $client_id]);
            $order_id = $this->pdo->lastInsertId();

            foreach ($productos as $producto) {
                $sql = "INSERT INTO order_details (order_id, product_id, quantity) VALUES (:order_id, :product_id, :quantity)";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([
                    'order_id' => $order_id,
                    'product_id' => $producto['id'],
                    'quantity' => $producto['cantidad']
                ]);
            }

            $this->pdo->commit();
            echo "Orden creada con éxito.";
        } catch (Exception $e) {
            $this->pdo->rollBack();
            echo "Error: " . $e->getMessage();
        }
    }
}

// Ejemplo de uso
// $pdo es una conexión PDO previamente establecida
// $orderController = new OrderController($pdo);
// $orderController->procesarOrden($client_id, $productos);

<?php
require 'config/db.php';

// Obtener clientes
$clientesQuery = "SELECT id, name FROM clients";
$clientes = $conn->query($clientesQuery);

// Manejo de selección de cliente
$cliente_id = isset($_POST['cliente_id']) ? $_POST['cliente_id'] : null;
$productos = [];

if ($cliente_id) {
    // Obtener productos disponibles para este cliente
    $productosQuery = "
        SELECT p.id, p.name, p.stock 
        FROM products p 
        JOIN client_product cp ON p.id = cp.product_id
        WHERE cp.client_id = ?";
    
    $stmt = $conn->prepare($productosQuery);
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $productos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Orden de Compra</title>
</head>
<body>
    <h1>Crear Orden de Compra</h1>

    <!-- Formulario de selección de cliente -->
    <form method="POST">
        <label for="cliente_id">Seleccione un Cliente:</label>
        <select name="cliente_id" onchange="this.form.submit()">
            <option value="">Seleccione...</option>
            <?php while ($cliente = $clientes->fetch_assoc()): ?>
                <option value="<?= $cliente['id']; ?>" <?= ($cliente_id == $cliente['id']) ? 'selected' : ''; ?>>
                    <?= $cliente['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>
    </form>

    <!-- Mostrar productos disponibles -->
    <?php if ($cliente_id && $productos): ?>
        <form action="procesar_orden.php" method="POST">
            <input type="hidden" name="cliente_id" value="<?= $cliente_id; ?>">
            <h2>Productos Disponibles</h2>
            <table border="1">
                <tr>
                    <th>Producto</th>
                    <th>Stock Disponible</th>
                    <th>Cantidad a Comprar</th>
                </tr>
                <?php foreach ($productos as $producto): ?>
                    <tr>
                        <td><?= $producto['name']; ?></td>
                        <td><?= $producto['stock']; ?></td>
                        <td>
                            <input type="number" name="productos[<?= $producto['id']; ?>]" min="1" max="<?= $producto['stock']; ?>">
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <button type="submit">Confirmar Orden</button>
        </form>
    <?php endif; ?>

</body>
</html>

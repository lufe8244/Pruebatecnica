prueba-tecnica-php/
├── src/
│   ├── config/
│   │   ├── db.php
│   ├── controllers/
│   │   ├── ClienteController.php
│   ├── models/
│   │   ├── Cliente.php
│   ├── views/
│       ├── index.php
├── public/
│   ├── index.php  <-- Asegúrate de que esté aquí
├── vendor/
├── composer.json
├── composer.lock

<?php
require 'config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cliente_id'], $_POST['productos'])) {
    $cliente_id = $_POST['cliente_id'];
    $productos = $_POST['productos'];

    // Verificar que al menos un producto tenga cantidad válida
    $productosValidos = array_filter($productos, fn($cantidad) => $cantidad > 0);
    if (empty($productosValidos)) {
        die("Error: Debe seleccionar al menos un producto con cantidad válida.");
    }

    // Iniciar la transacción
    $conn->begin_transaction();

    try {
        // Insertar la orden
        $stmt = $conn->prepare("INSERT INTO orders (client_id, order_date) VALUES (?, NOW())");
        $stmt->bind_param("i", $cliente_id);
        $stmt->execute();
        $order_id = $conn->insert_id;

        // Insertar productos en la orden y actualizar stock
        $stmtOrderProduct = $conn->prepare("INSERT INTO order_products (order_id, product_id, quantity) VALUES (?, ?, ?)");
        $stmtUpdateStock = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");

        foreach ($productosValidos as $product_id => $cantidad) {
            // Insertar en order_products
            $stmtOrderProduct->bind_param("iii", $order_id, $product_id, $cantidad);
            $stmtOrderProduct->execute();

            // Actualizar stock
            $stmtUpdateStock->bind_param("iii", $cantidad, $product_id, $cantidad);
            $stmtUpdateStock->execute();

            // Verificar si se afectó alguna fila (para asegurar que el stock es suficiente)
            if ($stmtUpdateStock->affected_rows === 0) {
                throw new Exception("Error: No hay suficiente stock para el producto ID $product_id.");
            }
        }

        // Confirmar transacción
        $conn->commit();
        echo "Orden creada exitosamente con ID: $order_id";

    } catch (Exception $e) {
        $conn->rollback();
        echo "Error en la orden: " . $e->getMessage();
    }
} else {
    echo "Acceso no autorizado.";
}
?>

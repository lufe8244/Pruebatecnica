<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../controllers/ClienteController.php';

$clienteController = new ClienteController($pdo);
$clientes = $clienteController->index();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <title>Lista de Clientes</title>
</head>
<body>
    <h2>Clientes</h2>
    <ul>
        <?php foreach ($clientes as $cliente): ?>
            <li><?= htmlspecialchars($cliente['nombre']) ?> - <?= htmlspecialchars($cliente['email']) ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
